#!/usr/bin/python3

def main(input_file):
	with open(input_file) as f:
		input_lines = [line.rstrip() for line in f.readlines()]

	regA = 0
	regB = 0
	regC = 0
	ops = list()

	for line in input_lines:
		if len(line) != 0:
			if line[9] == "B":
				regB = int(line.split(':')[1])
			elif line[9] == "C":
				regB = int(line.split(':')[1])				
			elif line[9] != "A":
				for ch in line.split(':')[1].split(','):
					ops.append(int(ch))

	
	result = 1
	nfound = 1
	first_A = 0
	out = list()
	
	while out != ops:
		regA = result
		pc = 0
		out = list()
		
		
		while pc < len(ops):	
			op = ops[pc]
			lit = combo = ops[pc+1]	
			if combo == 4:
				combo = regA
			elif combo == 5:
				combo = regB
			elif combo == 6:
				combo = regC
			elif combo == 7:
				continue
			if op == 0:
				regA = int(regA/(2**combo))
				if first_A == 0:
					first_A = regA
			elif op == 1:
				regB = regB ^ lit
			elif op == 2:
				regB = combo % 8
			elif op == 3:
				if regA != 0:
					pc = lit
					continue
			elif op == 4:
				regB = regB ^ regC
			elif op == 5:	
				out.append(combo%8)
				#if out[-1] != ops[len(out)-1]:
				#	break
					
			elif op == 6:
				regB = int(regA/(2**combo))
			elif op == 7:
				regC = int(regA/(2**combo))
			pc += 2

		if out == ops:
			return result
		if out[len(out)-nfound:] == ops[len(ops)-nfound:] :
			print(first_A,result)
			first_A = 0
			nfound += 1
	
		result += 1


if __name__ == "__main__":
	test_value = main("TEST1")
	expected_result = 117440
	assert test_value == expected_result,f"Test failed, expected {expected_result}, result {test_value}"
	print(main("INPUT"))
