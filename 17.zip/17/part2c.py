#!/usr/bin/python3

def main(input_file):
	with open(input_file) as f:
		input_lines = [line.rstrip() for line in f.readlines()]

	regA = 0
	regB = 0
	regC = 0
	ops = list()

	for line in input_lines:
		if len(line) != 0:
			if line[9] == "B":
				regB = int(line.split(':')[1])
			elif line[9] == "C":
				regB = int(line.split(':')[1])				
			elif line[9] != "A":
				for ch in line.split(':')[1].split(','):
					ops.append(int(ch))

	result = 0
	increments = [1]
	#[253,256,3,253,186,8,20,4,38,2,1,19,4,1,59,64,106,256,3,253,186,8,62,2,1]
	current_succession = list()
	nfound = 4
	last_found = 0
	index = 0
	first_value = 0

	out = list()

	
	while out != ops:
		regA = result
		#regA = int( input() )
		pc = 0
		out = list()

		while pc < len(ops):	
			op = ops[pc]
			lit = combo = ops[pc+1]
			
			if combo == 4:
				combo = regA
			elif combo == 5:
				combo = regB
			elif combo == 6:
				combo = regC
			elif combo == 7:
				continue
			
			if op == 0:
				regA = int(regA/(2**combo))
			elif op == 1:
				regB = regB ^ lit
			elif op == 2:
				regB = combo % 8
			elif op == 3:
				if regA != 0:
					pc = lit
					continue
			elif op == 4:
				regB = regB ^ regC
			elif op == 5:
				out.append(combo % 8 )
				if out[-1] != ops[len(out)-1]:
					break
			elif op == 6:
				regB = int(regA/(2**combo))
			elif op == 7:
				regC = int(regA/(2**combo))
			
			pc += 2
		
		#print(out)
		if out == ops:
			break
			
		#print(out,ops[:nfound],result)	
		#if len(out) >= nfound:
		if out[:nfound] == ops[:nfound]:
			print(result)
			
		result += increments[index%len(increments)]
		# ~ if nfound == 10:
	
		#gaa = input()
			# ~ print(result,increments,index)
		index += 1
	print(last_found,increments,result)
	return result

if __name__ == "__main__":
	#test_value = main("TEST1")
	#expected_result = 117440
	#assert test_value == expected_result,f"Test failed, expected {expected_result}, result {test_value}"
	print(main("INPUT"))
