#!/usr/bin/python3

def main(input_file):
	with open(input_file) as f:
		input_lines = [line.rstrip() for line in f.readlines()]

	regA = 0
	regB = 0
	regC = 0
	ops = list()

	for line in input_lines:
		if len(line) != 0:
			if line[9] == "B":
				regB = int(line.split(':')[1])
			elif line[9] == "C":
				regB = int(line.split(':')[1])				
			elif line[9] != "A":
				for ch in line.split(':')[1].split(','):
					ops.append(int(ch))

	result = 164545589767868
	increments = [-1]
	current_succession = list()
	nfound = 4
	last_found = 0
	index = 0
	first_value = 0

	out = list()

	
	while True:#out != ops:
		regA = result
		pc = 0
		out = list()

		while pc < len(ops):	
			op = ops[pc]
			lit = combo = ops[pc+1]
			
			if combo == 4:
				combo = regA
			elif combo == 5:
				combo = regB
			elif combo == 6:
				combo = regC
			elif combo == 7:
				continue
			
			if op == 0:
				regA = int(regA/(2**combo))
			elif op == 1:
				regB = regB ^ lit
			elif op == 2:
				regB = combo % 8
			elif op == 3:
				if regA != 0:
					pc = lit
					continue
			elif op == 4:
				regB = regB ^ regC
			elif op == 5:
				out.append(combo % 8 )
				if out[-1] != ops[len(out)-1]:
					break
			elif op == 6:
				regB = int(regA/(2**combo))
			elif op == 7:
				regC = int(regA/(2**combo))
			
			pc += 2
		
		#print(out)
		#print("[2, 4, 1, 1, 7, 5, 1, 5, 4, 0, 0, 3, 5, 5, 3, 0]")
		
		if out == ops:
			return result
		#quit()	
		# ~ if len(out) >= nfound:
			# ~ if out[:nfound] == ops[:nfound]:
				# ~ diff = result - last_found
				# ~ last_found = result
				# ~ if first_value != 0:
					# ~ current_succession.append(diff)
				# ~ else:
					# ~ first_value = result
				# ~ #print(current_succession)
				# ~ if len(current_succession) > 1 and (len(current_succession) / 2 == len(current_succession) // 2 ):
					# ~ #print(current_succession[len(current_succession)//2:-1],current_succession[1:len(current_succession)//2])
					# ~ if current_succession[len(current_succession)//2:] == current_succession[:len(current_succession)//2]:
						# ~ increments = list()
						# ~ for cs in current_succession[len(current_succession)//2:]:
							# ~ increments.append(cs)
						# ~ nfound +=2
						# ~ index = 0
						# ~ if nfound == 10:
							# ~ print(current_succession,first_value,result,increments)
							# ~ quit()
						# ~ result = first_value
						# ~ first_value = 0
						# ~ #print(increments,result)
						# ~ print(nfound)
						# ~ current_succession = list()
			
		# ~ result += increments[index%len(increments)]
		# ~ if nfound == 10:
	
			# ~ gaa = input()
			# ~ print(result,increments,index)
		#index += 1
		result -= 1
		# ~ print(out,result)
		# ~ ab = input()
		# ~ if ab:
			# ~ result = ab
	

if __name__ == "__main__":
	#test_value = main("TEST1")
	#expected_result = 117440
	#assert test_value == expected_result,f"Test failed, expected {expected_result}, result {test_value}"
	print(main("INPUT"))
